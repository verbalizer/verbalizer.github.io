PROTEGE VERBALIZER PLUGIN

This plugin is to be used with Protege. So far it has only been tested with Protege 5. It was developed to work with OWL EL ontologies. Please note that if you try it out with more expressive ontologies, it may fail. 

INSTALLATION

To install the plugin, move or copy the enclosed jar file to the "plugins" folder of your Protege installation. Depending on your system, the name of this folder may vary. 

USE

- In Protege, classify an ontology (e.g. the enclosed example ontology) 
- Inspect one of the inferred inferences (highlighted in yellow). When clicking on the question mark, a window will pop up. 
- Select the "Verbalized Proof Based Explanation" to view the generated explanation text.

If you find bugs or have any comments, please contact the author (https://www.uni-ulm.de/in/ki/staff/marvinschiller.html). 

You find further information at https://verbalizer.github.io

LICENSE

This software is made available under the Apache 2.0 license. It uses the following libraries in unmodified form:

- OWL API:http://owlapi.sourceforge.net/. The OWL API is open source software and available under the LGPL and Apache licenses.
- Java API for WordNet Searching (JAWS): http://lyle.smu.edu/~tspell/jaws/. Use and distribution is permitted by this license: http://morphadorner.northwestern.edu/licenses/thirdparty/jaws.html
- Protege libraries: http://protege.stanford.edu/. Protege is open source software available under the Mozilla Public License 1.1.
